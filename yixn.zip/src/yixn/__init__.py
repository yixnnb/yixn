from .email_sender import Mailer, send_quick, send_text

__all__ = ['Mailer', 'send_quick', 'send_text']
__version__ = '0.1.0'