import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Optional, Union
from pathlib import Path

class Mailer:
    """通用邮件发送器（支持附件、多服务器）"""
    
    # 常用邮箱服务器配置（自动适配）
    SMTP_CONFIGS = {
        'qq': {'server': 'smtp.qq.com', 'port': 465, 'ssl': True},
        '163': {'server': 'smtp.163.com', 'port': 465, 'ssl': True},
        'gmail': {'server': 'smtp.gmail.com', 'port': 587, 'ssl': False},
        'outlook': {'server': 'smtp-mail.outlook.com', 'port': 587, 'ssl': False},
        '126': {'server': 'smtp.126.com', 'port': 465, 'ssl': True},
        'yeah': {'server': 'smtp.yeah.net', 'port': 465, 'ssl': True},
    }
    
    def __init__(self, username: str, password: str, 
                 smtp_server: Optional[str] = None, 
                 smtp_port: Optional[int] = None,
                 use_ssl: Optional[bool] = None):
        """
        初始化邮件发送器
        
        :param username: 发件邮箱（如 your@163.com）
        :param password: 授权码（不是登录密码！）
        :param smtp_server: SMTP服务器地址（自动识别可留空）
        :param smtp_port: 端口（自动识别可留空）
        :param use_ssl: 是否使用SSL（自动识别可留空）
        
        示例：
            # 自动识别163邮箱
            mailer = Mailer('your@163.com', '授权码')
            
            # 手动指定（兼容所有服务器）
            mailer = Mailer('your@custom.com', '密码', 
                           smtp_server='smtp.custom.com', 
                           smtp_port=587, use_ssl=False)
        """
        self.username = username
        
        # 自动识别邮箱服务器
        if smtp_server is None or smtp_port is None:
            domain = username.split('@')[-1].split('.')[0]  # 提取域名前缀
            if domain in self.SMTP_CONFIGS:
                config = self.SMTP_CONFIGS[domain]
                smtp_server = smtp_server or config['server']
                smtp_port = smtp_port or config['port']
                use_ssl = use_ssl if use_ssl is not None else config['ssl']
            else:
                raise ValueError(f"无法识别邮箱域名: {domain}，请手动指定 smtp_server 和 smtp_port")
        
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.password = password
        self.use_ssl = use_ssl if use_ssl is not None else True
    
    def send(self, to_emails: Union[str, List[str]], 
             subject: str, 
             body: str = "",
             html_body: Optional[str] = None,
             attachments: Optional[List[Union[str, Path]]] = None,
             is_html: bool = False) -> bool:
        """
        通用发送方法（支持文本/HTML/附件）
        
        :param to_emails: 收件人（字符串或列表）
        :param subject: 主题
        :param body: 纯文本正文
        :param html_body: HTML正文（优先级高于body）
        :param attachments: 附件路径列表
        :param is_html: body是否为HTML（当html_body为None时生效）
        :return: 是否成功
        """
        # 统一收件人为列表
        if isinstance(to_emails, str):
            to_emails = [to_emails]
        
        try:
            # 创建邮件对象
            msg = MIMEMultipart()
            msg['From'] = self.username
            msg['To'] = ', '.join(to_emails)
            msg['Subject'] = subject
            
            # 处理正文（优先使用html_body）
            if html_body:
                msg.attach(MIMEText(html_body, 'html', 'utf-8'))
            elif is_html:
                msg.attach(MIMEText(body, 'html', 'utf-8'))
            else:
                msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            # 添加附件
            if attachments:
                for file_path in attachments:
                    self._attach_file(msg, file_path)
            
            # 发送
            if self.use_ssl:
                with smtplib.SMTP_SSL(self.smtp_server, self.smtp_port) as server:
                    server.login(self.username, self.password)
                    server.sendmail(self.username, to_emails, msg.as_string())
            else:
                with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                    server.starttls()  # 启用TLS加密
                    server.login(self.username, self.password)
                    server.sendmail(self.username, to_emails, msg.as_string())
            
            print(f"✅ 邮件发送成功！收件人: {', '.join(to_emails)}")
            return True
            
        except Exception as e:
            print(f"❌ 发送失败: {e}")
            return False
    
    def _attach_file(self, msg: MIMEMultipart, file_path: Union[str, Path]):
        """内部方法：添加附件"""
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"附件不存在: {file_path}")
        
        with open(file_path, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header(
                'Content-Disposition',
                f'attachment; filename="{file_path.name}"'
            )
            msg.attach(part)


# ========== 快捷函数 ==========

def send_quick(to: Union[str, List[str]], 
               subject: str, 
               body: str = "",
               attachments: Optional[List[str]] = None,
               user: Optional[str] = None, 
               pwd: Optional[str] = None) -> bool:
    """
    一行代码发邮件（含附件）
    
    优先使用环境变量: EMAIL_USER, EMAIL_PWD
    """
    if user is None or pwd is None:
        import os
        user = user or os.getenv('EMAIL_USER')
        pwd = pwd or os.getenv('EMAIL_PWD')
        if not user or not pwd:
            raise ValueError("请设置邮箱和授权码（或通过环境变量 EMAIL_USER/EMAIL_PWD）")
    
    mailer = Mailer(user, pwd)
    return mailer.send(to, subject, body, attachments=attachments)


# ========== 兼容旧版本 ==========
def send_text(to, subject, body, user=None, pwd=None):
    """兼容旧版纯文本发送"""
    return send_quick(to, subject, body, user=user, pwd=pwd)